# Hướng dẫn triển khai — Cá nhân hóa & Lưu trữ ngoại tuyến (History, Favorites & Offline Cache)

## A. Backend Spring Boot

1. Đưa package `com.smatheritage.personalization` vào backend chính, đổi package nếu quy ước nhóm khác.
2. Thay entity minh họa `VisitorAccount` và `Artifact` bằng entity `User` và `Artifact` đã có trong hệ thống. Không tạo bảng người dùng/hiện vật trùng lặp.
3. Đảm bảo principal sau đăng nhập có thể lấy UUID người dùng. Có thể implement `CurrentUserPrincipal` hoặc sửa `SecurityContextCurrentUserProvider` để map principal hiện tại.
4. Giữ `VisitHistory` và `Favorite` là các bảng liên kết tới User/Artifact hiện hữu. Giữ unique constraint `(visitor_id, client_event_id)` và `(visitor_id, artifact_id)`.
5. Đưa API và service vào security rules của backend chính; các route `/me/**` phải cần đăng nhập. Demo Basic Auth chỉ dùng local.
6. Kết nối `ArtifactContentRepository` tới dữ liệu nội dung đa ngôn ngữ thực tế. `contentHash` cần được tính/đổi khi nội dung hoặc asset thay đổi.
7. Thay H2 bằng DB dự án; dùng migration (Flyway/Liquibase/SQL của nhóm) thay cho `ddl-auto=update` trong production.

## B. Mobile offline implementation

1. Khi người dùng xem artifact, ghi history event vào local outbox trước.
2. Khi thiết bị mất mạng, dùng `cached_artifact` để hiện nội dung đã tải. Cache key tối thiểu là `(artifactId, languageCode)`.
3. Khi online, gọi manifest; so `contentHash`. Tải những nội dung khác hash, lưu file vào vùng app-private, cập nhật local DB khi tải hoàn tất.
4. Đồng bộ history batches với UUID `clientEventId` ổn định qua các lần retry.
5. Favorites cập nhật UI trước; lưu ADD/REMOVE vào outbox và replay theo thứ tự lúc có mạng. Xóa lệnh queue sau khi API thành công.
6. Thêm trạng thái `PENDING`, `SYNCED`, `FAILED` trên UI nếu phù hợp, nhưng không cho trạng thái mạng ngăn người dùng xem cache.
7. Test airplane mode, tắt Bluetooth sau khi mở nội dung, đổi ngôn ngữ, cập nhật hash và logout.

## C. Demo local

Mở terminal ở thư mục có `pom.xml`, chạy `mvn spring-boot:run -Dspring-boot.run.profiles=demo`. Dùng Basic Auth `visitor / demo123`, chỉ trên local. Demo IDs nằm trong README.

## D. Khi commit

```bash
git add src/main/java/com/smatheritage/personalization docs
 git commit -m "feat: add visitor history favorites and offline cache support"
git push origin <your-branch>
```

Nếu repository nhóm đã có cấu trúc khác, hãy copy các class phù hợp thay vì chép đè toàn bộ `pom.xml`/cấu hình server.
