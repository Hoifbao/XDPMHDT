# Phạm vi nhiệm vụ — Cá nhân hóa & Lưu trữ ngoại tuyến

## Ánh xạ tới yêu cầu Smart Heritage

| Yêu cầu | Phần được chuẩn bị | Cách nghiệm thu |
|---|---|---|
| US06 — Tiếp tục xem nội dung sau khi ra khỏi vùng beacon | `OfflineCacheController`, `OfflineCacheService`, manifest có `languageCode`, URL, `contentHash`, `updatedAt`; schema local `cached_artifact`; flow cache | Tải nội dung khi online, tắt Wi-Fi/Bluetooth, mở lại được bản đã lưu. Backend chỉ cung cấp manifest; cache thực tế nằm trong app điện thoại. |
| US07 — Favorites và History | `FavoriteController/Service/Repository`, `VisitHistoryController/Service/Repository` | Thêm/xóa favorite idempotent; lịch sử được phân trang mới nhất trước. |
| US21 — Đồng bộ tương tác giữa app và backend | `POST /api/v1/me/history/sync`; `clientEventId` ổn định, batch 1–100, duplicate được đếm | Gửi lại batch có cùng ID, không phát sinh bản ghi trùng. |
| US22 — Ghi nhận lượt xem để phân tích | Entity `VisitHistory`, `VisitSource`, `visitedAt`, `beaconCode` | Lịch sử lưu được source IBEACON/MANUAL/MAP và thời điểm; nhóm Analytics có thể đọc dữ liệu này sau khi tích hợp. |
| US24 — Lưu dữ liệu an toàn | `CurrentUserProvider` lấy user từ Spring Security; API `/me/**` không nhận `visitorId` trong body | Request không đăng nhập bị từ chối; history/favorites chỉ trả của principal đang đăng nhập. |

## Thành phần trong gói

- Backend demo Spring Boot + Spring Data JPA + H2.
- Unit tests hiện có và `PersonalizationApiIntegrationTest` cho authentication, account isolation, favorite idempotency, history sync, all-or-nothing batch và manifest.
- API contract và OpenAPI YAML.
- Postman collection.
- SQLite schema cho mobile, sơ đồ lớp, domain model và offline/sync flow.
- Hướng dẫn chạy, kiểm thử và tích hợp vào backend chính.

## Giới hạn cần nói rõ với nhóm

Đây là module backend độc lập minh họa bằng entity `VisitorAccount` và `Artifact` tối giản. Khi ghép vào backend chính, phải thay các entity đó bằng `User`/`Artifact` thực tế và ánh xạ principal JWT đang có; không tạo bảng trùng.

Chức năng lưu offline thực sự phải chạy trên app mobile. Gói này cung cấp schema SQLite và logic/flow độc lập framework nhưng **chưa bao gồm màn hình hoặc mã local database cho Flutter/React Native/Kotlin**, vì framework mobile của repository chính chưa được xác định. Cần triển khai phần client theo framework đó.

Các test đã được viết nhưng trong môi trường tạo gói hiện tại không có Maven và không thể tải Maven/dependencies do kết nối DNS ngoài bị chặn; vì vậy không được xem là đã chạy test thành công ở đây. Hãy chạy `mvn test` trên máy dự án sau khi Maven tải được dependency.
