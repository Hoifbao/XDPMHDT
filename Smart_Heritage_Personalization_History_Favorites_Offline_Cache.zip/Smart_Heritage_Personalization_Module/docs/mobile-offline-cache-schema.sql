-- Platform-neutral SQLite schema for the mobile client.
-- This is LOCAL mobile storage, not the Spring Boot server schema.
-- Account-specific rows are scoped by owner_user_id to prevent cross-account leakage.

-- Public, language-specific content can be retained across logins if product policy allows it.
CREATE TABLE IF NOT EXISTS cached_artifact (
    artifact_id TEXT NOT NULL,
    site_id TEXT NOT NULL,
    language_code TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    thumbnail_local_path TEXT,
    content_local_path TEXT,
    content_hash TEXT NOT NULL,
    content_updated_at TEXT NOT NULL,
    cached_at TEXT NOT NULL,
    last_accessed_at TEXT NOT NULL,
    file_size_bytes INTEGER NOT NULL DEFAULT 0 CHECK (file_size_bytes >= 0),
    cache_complete INTEGER NOT NULL DEFAULT 0 CHECK (cache_complete IN (0, 1)),
    PRIMARY KEY (artifact_id, language_code)
);

-- Local history view: keep this after successful sync so History works offline.
-- This table is distinct from local_visit_outbox, which contains only pending uploads.
CREATE TABLE IF NOT EXISTS local_visit_history (
    local_history_id TEXT PRIMARY KEY,
    owner_user_id TEXT NOT NULL,
    client_event_id TEXT NOT NULL,
    artifact_id TEXT NOT NULL,
    artifact_title_snapshot TEXT NOT NULL,
    thumbnail_local_path TEXT,
    visited_at TEXT NOT NULL,
    source TEXT NOT NULL CHECK (source IN ('IBEACON', 'MANUAL', 'MAP')),
    beacon_code TEXT,
    sync_state TEXT NOT NULL DEFAULT 'PENDING' CHECK (sync_state IN ('PENDING', 'SYNCED', 'FAILED')),
    created_at TEXT NOT NULL,
    UNIQUE (owner_user_id, client_event_id)
);

-- Durable outbox. Keep owner_user_id locally; do not send it in the API body.
-- Only synchronize rows whose owner_user_id matches the currently authenticated account.
CREATE TABLE IF NOT EXISTS local_visit_outbox (
    client_event_id TEXT PRIMARY KEY,
    owner_user_id TEXT NOT NULL,
    artifact_id TEXT NOT NULL,
    visited_at TEXT NOT NULL,
    source TEXT NOT NULL CHECK (source IN ('IBEACON', 'MANUAL', 'MAP')),
    beacon_code TEXT,
    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
    last_error TEXT,
    created_at TEXT NOT NULL,
    last_attempt_at TEXT
);

-- Local favorites mirror the current UI state for the signed-in account.
CREATE TABLE IF NOT EXISTS local_favorite_state (
    owner_user_id TEXT NOT NULL,
    artifact_id TEXT NOT NULL,
    is_favorite INTEGER NOT NULL CHECK (is_favorite IN (0, 1)),
    updated_at TEXT NOT NULL,
    sync_pending INTEGER NOT NULL DEFAULT 0 CHECK (sync_pending IN (0, 1)),
    PRIMARY KEY (owner_user_id, artifact_id)
);

-- Ordered operation outbox is required: ADD then REMOVE cannot be represented by a boolean alone.
CREATE TABLE IF NOT EXISTS local_favorite_outbox (
    client_operation_id TEXT PRIMARY KEY,
    owner_user_id TEXT NOT NULL,
    artifact_id TEXT NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('ADD', 'REMOVE')),
    occurred_at TEXT NOT NULL,
    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
    last_error TEXT
);

CREATE INDEX IF NOT EXISTS idx_cached_artifact_site_language
    ON cached_artifact(site_id, language_code);
CREATE INDEX IF NOT EXISTS idx_cached_artifact_lru
    ON cached_artifact(last_accessed_at);
CREATE INDEX IF NOT EXISTS idx_local_history_account_time
    ON local_visit_history(owner_user_id, visited_at DESC);
CREATE INDEX IF NOT EXISTS idx_visit_outbox_account_created
    ON local_visit_outbox(owner_user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_favorite_outbox_account_time
    ON local_favorite_outbox(owner_user_id, occurred_at);
