# API Contract — Cá nhân hóa & Lưu trữ ngoại tuyến (History, Favorites & Offline Cache)

Base path: `/api/v1`. JSON UTF-8. Timestamps are ISO-8601 UTC instants. UUIDs are strings. The current user is always resolved from Spring Security; do not send a `visitorId` from the client.

## 1. History

### `GET /me/history?page=0&size=20`
Returns a paginated list sorted by `visitedAt DESC`. `size` must be 1..100.

### `POST /me/history/sync`
Accepts 1..100 offline-recorded events. Each event requires `clientEventId`, `artifactId`, `visitedAt`, and `source`; `beaconCode` is optional. Duplicate `{currentUser, clientEventId}` is counted as duplicate and is not inserted again. The batch is transactional/all-or-nothing.

Success example:
```json
{"received":2,"created":1,"duplicates":1}
```

## 2. Favorites

### `GET /me/favorites?page=0&size=20`
Returns paginated list sorted by `createdAt DESC`.

### `PUT /me/favorites/{artifactId}`
Returns `204 No Content`. Repeat calls do not create duplicate rows.

### `DELETE /me/favorites/{artifactId}`
Returns `204 No Content`. Deleting a non-favorite is also successful, so clients can replay queued actions safely.

### `GET /me/favorites/{artifactId}/exists`
Returns boolean `true` or `false`.

## 3. Offline cache manifest

### `GET /offline-cache/manifest?siteId={uuid}&language=vi`
Returns published artifact content for the site and language, including `contentHash`, `updatedAt`, thumbnail URL, and content URL. Mobile compares the hash/version to its local cache and only downloads changed content.

Example:
```json
{
  "siteId":"20000000-0000-0000-0000-000000000001",
  "languageCode":"vi",
  "generatedAt":"2026-10-20T09:20:00Z",
  "itemCount":1,
  "items":[{
    "artifactId":"30000000-0000-0000-0000-000000000001",
    "languageCode":"vi",
    "title":"Mẫu hiện vật Smart Heritage",
    "description":"Nội dung minh họa cho chức năng cache ngoại tuyến.",
    "thumbnailUrl":"https://example.test/images/artifact.jpg",
    "contentUrl":"https://example.test/content/artifact.html",
    "contentHash":"demo-hash-v1",
    "updatedAt":"2026-10-20T09:20:00Z"
  }]
}
```


See [`openapi-personalization.yaml`](openapi-personalization.yaml) for the machine-readable API specification and [`DEMO_API_TESTING.md`](DEMO_API_TESTING.md) for Postman and local-test instructions.
