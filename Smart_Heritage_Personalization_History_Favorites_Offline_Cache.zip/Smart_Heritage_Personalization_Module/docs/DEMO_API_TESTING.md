# Kiểm thử API cho module Personalization

## 1. Chạy ứng dụng demo

Yêu cầu JDK 17+ và Maven 3.9+.

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=demo
```

Demo dùng H2 in-memory và Basic Auth chỉ để test local. Không dùng tài khoản demo hoặc cấu hình này trên môi trường production.

- Base URL: `http://localhost:8080`
- Username: `visitor`
- Password: `demo123`
- Site ID: `20000000-0000-0000-0000-000000000001`
- Artifact ID: `30000000-0000-0000-0000-000000000001`

## 2. Postman

Import file [`postman/Smart_Heritage_Personalization.postman_collection.json`](../postman/Smart_Heritage_Personalization.postman_collection.json) vào Postman. Collection variables cho `baseUrl`, `username`, `password`, `siteId`, `artifactId` và `clientEventId` được khai báo sẵn; đổi `clientEventId` thành UUID mới khi muốn kiểm thử một lượt sync mới.

Chạy lần lượt các request: xem manifest, lấy history, sync history, thêm favorite, kiểm tra favorite, xem danh sách favorite và xóa favorite. Chạy lại request sync với cùng `clientEventId` để kiểm tra idempotency.

## 3. Unit và API integration tests

```bash
mvn test
```

Các unit test kiểm tra logic idempotent của favorite, duplicate offline event và manifest hash/ngôn ngữ. `PersonalizationApiIntegrationTest` kiểm tra HTTP authentication, favorites, sync idempotent và manifest trên H2 với profile `demo`.

## 4. Checklist thủ công

- [ ] Chưa đăng nhập: các route `/api/v1/me/**` trả `401`.
- [ ] Thêm favorite bằng PUT nhiều lần: vẫn chỉ có một record.
- [ ] Xóa favorite nhiều lần: vẫn trả `204`.
- [ ] Gửi cùng `clientEventId` nhiều lần: chỉ ghi một lịch sử.
- [ ] Manifest `language=vi` không trả bản dịch `en`.
- [ ] Mobile mở nội dung đã cache khi tắt Wi-Fi/Bluetooth.
- [ ] Favorite/history offline không bị gửi dưới tài khoản khác sau khi logout/login.
- [ ] Content download lỗi giữa chừng không ghi cache thành complete.
