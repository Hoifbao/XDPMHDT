# Test Cases — Cá nhân hóa & Lưu trữ ngoại tuyến (History, Favorites & Offline Cache)

| ID | Scenario | Expected result |
|---|---|---|
| P5-HIS-01 | Authorized visitor requests history | Only current user's records are returned, newest first |
| P5-HIS-02 | Same event is submitted twice with identical `clientEventId` | One history row; second submission counted as duplicate |
| P5-HIS-03 | Batch contains an unpublished/missing artifact | Entire batch rolls back in current starter implementation |
| P5-HIS-04 | `size=500` or `page=-1` | HTTP 400 validation error |
| P5-FAV-01 | Add favorite once | Favorite appears in list |
| P5-FAV-02 | Repeat PUT for same artifact | Still only one favorite row |
| P5-FAV-03 | Repeat DELETE for same artifact | Both return 204 |
| P5-FAV-04 | User A lists favorites | No records owned by user B are returned |
| P5-CACHE-01 | Request manifest for site/language | Only published matching translations are returned |
| P5-CACHE-02 | Manifest hash differs from local cache hash | Mobile re-downloads that content |
| P5-CACHE-03 | Device exits beacon range or network disappears after content cached | Mobile displays local copy without needing beacon/network |
| P5-SYNC-01 | Offline visits queued and network returns | App submits batch; removes events only after acknowledgement |
| P5-SEC-01 | Request history/favorites without authentication | Request rejected by real project security configuration |
