# Offline Cache Design — Mobile Responsibilities

## Core principle
The content cache physically lives on the visitor's phone. Backend provides a manifest, canonical content URLs, language-specific content, and a content hash/version. Backend also accepts queued visit-history events and normal online favorite operations. It cannot guarantee offline behavior unless the mobile app stores and reads its own local data.

## Suggested local stores (framework-agnostic)

**CachedArtifact**: `artifactId` (PK), `siteId`, `languageCode`, `title`, `description`, `thumbnailLocalPath`, `contentLocalPath`, `contentHash`, `updatedAt`, `cachedAt`.

**LocalVisitEvent (outbox)**: `clientEventId` (PK UUID), `artifactId`, `visitedAt`, `source`, `beaconCode`, `syncState`, `attemptCount`, `lastError`.

**LocalFavorite**: `artifactId` (PK), `isFavorite`, `updatedAt`, `syncState`. If an offline favorite is removed, preserve an ordered outbox command (`ADD`/`REMOVE`) until server acknowledgement; a simple set alone cannot preserve operation ordering.

## Read path

1. User taps an artifact or moves into beacon range.
2. Look up content by `{artifactId, languageCode}` in local DB.
3. If present, show immediately; if online, optionally refresh in background against manifest/hash.
4. If missing and online, fetch content, download necessary assets, then persist metadata/files before marking cache complete.
5. If missing and offline, show a clear unavailable state rather than a blank screen.

## Sync path

1. Persist a visit event locally before making a network call.
2. On connectivity restoration, send outbox batches (maximum 100 events for this backend contract).
3. Retry on timeout/network error using the same `clientEventId`; this makes retries idempotent.
4. Delete local outbox rows only for acknowledged events.
5. Replay favorite operations in timestamp order through idempotent PUT/DELETE endpoints.

## Cache invalidation and privacy

- Compare `contentHash` or `updatedAt` from manifest, not only the artifact title.
- A partially downloaded item must not be marked cache-complete.
- Do not cache passwords or bearer tokens.
- Decide with the team whether favorite/offline content is retained after logout; default safe policy is to remove account-specific history/favorite cache on logout while optionally retaining public artifact content.
- Set and document a storage quota; the proposal value must be agreed by the team rather than presented as a source requirement.

## Account isolation and visible offline history

The local schema now separates three ideas that must not be mixed:

1. `local_visit_history` is the local history view. Keep an entry after the upload succeeds so the visitor can still view history without a connection.
2. `local_visit_outbox` contains only visit events waiting to be uploaded. Remove an outbox row only after the server acknowledges the event; do not delete its corresponding local history row.
3. `local_favorite_state` is the state shown in the UI, while `local_favorite_outbox` is the ordered list of unsent ADD/REMOVE commands.

Each account-specific local row records `owner_user_id`. This value is a local isolation key only: do not include it in an API request. Backend derives the account from the authenticated principal. On login, only show/sync rows scoped to the currently authenticated account; on logout, clear account-specific history/favorites/outbox according to the agreed privacy policy. Public artifact content may remain cached if the project approves that behavior.

## Suggested offline acceptance flow

- When an artifact is opened, insert a `local_visit_history` row and a matching `local_visit_outbox` row in one local transaction before attempting network sync.
- The artifact reader checks `cached_artifact` by `(artifact_id, language_code)`. A row can be read only when `cache_complete = 1` and required local files still exist.
- Download content and media to temporary files first. Verify the hash if the backend hash represents the downloaded payload; rename/move files and set `cache_complete = 1` only after all required assets succeed.
- When sync acknowledges an event, update local history to `SYNCED` and delete only the corresponding outbox row.
- If a manifest returns a different `contentHash`, refresh the content and all relevant media atomically. If download fails, keep the previous complete cache intact.
- The cache quota and eviction policy must be chosen by the team. Prefer removing least-recently-used cached media/content while preserving local favorite state and unsynced outbox records.
