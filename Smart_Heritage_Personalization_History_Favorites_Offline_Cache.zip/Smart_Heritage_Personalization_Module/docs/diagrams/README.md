# Biểu đồ — Cá nhân hóa & Lưu trữ ngoại tuyến (History, Favorites & Offline Cache)

- `Personalization_Class_Diagram.drawio`: sơ đồ lớp có thể chỉnh sửa trong diagrams.net.
- `Personalization_Class_Diagram.dot`: nguồn Graphviz cho sơ đồ lớp.
- `Personalization_Class_Diagram.puml`: nguồn PlantUML cho sơ đồ lớp.
- `Personalization_Class_Diagram.mmd`: nguồn Mermaid cho kiến trúc lớp.
- `Personalization_Class_Diagram.png` và `.svg`: bản xem trước đã xuất từ nguồn Graphviz.
- `Personalization_Domain_Model.dot`, `.png`, `.svg`: mô hình miền và quan hệ dữ liệu.
- `Offline_Sync_Flow.dot`, `.mmd`, `.png`, `.svg`: luồng cache ngoại tuyến và đồng bộ lịch sử.

- Offline implementation now models persistent local History separately from the pending sync outbox, plus an ordered Favorite operation queue. See `../OFFLINE_CACHE_DESIGN.md` and `../mobile-offline-cache-schema.sql`.
