@echo off
setlocal
cd /d "%~dp0\.."
where mvn >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Maven was not found on PATH.
  echo Install Maven 3.9+ or open the project in IntelliJ IDEA and run the Maven goal: test
  exit /b 1
)
mvn test
endlocal
