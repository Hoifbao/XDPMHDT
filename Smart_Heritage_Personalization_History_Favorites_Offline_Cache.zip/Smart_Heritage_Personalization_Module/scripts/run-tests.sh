#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
if ! command -v mvn >/dev/null 2>&1; then
  echo "[ERROR] Maven 3.9+ was not found on PATH." >&2
  exit 1
fi
exec mvn test
