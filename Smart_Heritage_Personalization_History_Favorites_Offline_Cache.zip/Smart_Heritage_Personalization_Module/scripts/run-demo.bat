@echo off
setlocal
cd /d "%~dp0\.."
where java >nul 2>nul
if errorlevel 1 (
  echo [ERROR] JDK 17 or newer was not found on PATH.
  echo Install a JDK and reopen the terminal, then try again.
  exit /b 1
)
where mvn >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Maven was not found on PATH.
  echo Install Maven 3.9+ or open the project in IntelliJ IDEA and run the Maven goal:
  echo spring-boot:run -Dspring-boot.run.profiles=demo
  exit /b 1
)
echo Starting Smart Heritage Personalization demo at http://localhost:8080
mvn spring-boot:run -Dspring-boot.run.profiles=demo
endlocal
