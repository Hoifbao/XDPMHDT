# Smart Heritage — Cá nhân hóa & Lưu trữ ngoại tuyến (History, Favorites & Offline Cache)

**Phạm vi:** History, Favorites & Offline Cache. Bộ mã mẫu dùng Java 17+ + Spring Boot 3.5.x, Spring Web, Validation, Spring Data JPA, Spring Security và H2 cho demo cục bộ.

## Bám theo yêu cầu đề tài

- **US06:** tiếp tục xem thông tin hiện vật sau khi ra khỏi vùng phủ beacon — ứng dụng di động phải lưu nội dung đã tải xuống vào cache cục bộ.
- **US07:** lưu hiện vật yêu thích và xem lại lịch sử tham quan.
- **US21/US22:** đồng bộ sự kiện tương tác và ghi nhận lịch sử để phục vụ thống kê.
- **US24:** dữ liệu phải được lưu an toàn; lịch sử/yêu thích lấy theo người dùng đã xác thực, không nhận `userId` từ request body.

## Phân ranh trách nhiệm

- **Backend Spring Boot:** REST API lịch sử, API yêu thích, nhận batch lịch sử được ghi khi offline, cung cấp offline-cache manifest và phiên bản/hash nội dung.
- **Ứng dụng di động:** quét beacon, tải nội dung/media, lưu cache vào database/file cục bộ, hiển thị cache khi mất mạng/ra khỏi beacon, queue các sự kiện và thao tác yêu thích khi offline rồi đồng bộ khi có mạng. Lược đồ SQLite đã được chuẩn hóa theo `owner_user_id` để ngăn đồng bộ chéo tài khoản.
- Manifest chỉ là danh sách nội dung/URL/phiên bản; Backend không thể tự ghi cache lên điện thoại. Mobile team cần chọn công nghệ lưu cục bộ theo framework app của dự án.

## Chạy demo cục bộ

Cần JDK 17+ và Maven 3.9+.

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=demo
```

Chạy test bằng `mvn test` hoặc `scripts\run-tests.bat`. Có thể dùng `scripts\run-demo.bat` trên Windows. Thông tin đăng nhập **chỉ cho demo cục bộ**:

- Username: `visitor`
- Password: `demo123`
- Demo site ID: `20000000-0000-0000-0000-000000000001`
- Demo artifact ID: `30000000-0000-0000-0000-000000000001`

Không sử dụng profile/credential demo trong production. Khi tích hợp vào repository chính, bỏ `DemoSecurityConfig`, `DemoVisitorPrincipal`, `DemoDataInitializer` và thay bằng Security/JWT hiện có. Principal do JWT trả về cần implement `CurrentUserPrincipal#getUserId()` (hoặc sửa `SecurityContextCurrentUserProvider` để ánh xạ principal hiện tại).

## API and testing resources

- OpenAPI specification: [`docs/openapi-personalization.yaml`](docs/openapi-personalization.yaml).
- Postman collection: [`postman/Smart_Heritage_Personalization.postman_collection.json`](postman/Smart_Heritage_Personalization.postman_collection.json).
- API testing guide: [`docs/DEMO_API_TESTING.md`](docs/DEMO_API_TESTING.md).
- Windows quick start: run [`scripts/run-demo.bat`](scripts/run-demo.bat); run tests with [`scripts/run-tests.bat`](scripts/run-tests.bat).
- Mobile SQLite schema: [`docs/mobile-offline-cache-schema.sql`](docs/mobile-offline-cache-schema.sql). It is for the app's local database, not the server database.

## API

| Method | Endpoint | Tác dụng |
|---|---|---|
| GET | `/api/v1/me/history?page=0&size=20` | Lấy lịch sử tham quan của người đang đăng nhập |
| POST | `/api/v1/me/history/sync` | Đồng bộ tối đa 100 sự kiện đã xếp hàng trên điện thoại; `clientEventId` giúp chống ghi trùng khi retry |
| GET | `/api/v1/me/favorites?page=0&size=20` | Lấy danh sách yêu thích |
| PUT | `/api/v1/me/favorites/{artifactId}` | Thêm yêu thích; thao tác idempotent |
| DELETE | `/api/v1/me/favorites/{artifactId}` | Bỏ yêu thích; thao tác idempotent |
| GET | `/api/v1/me/favorites/{artifactId}/exists` | Kiểm tra trạng thái yêu thích |
| GET | `/api/v1/offline-cache/manifest?siteId={uuid}&language=vi` | Lấy manifest để mobile kiểm tra/tải nội dung offline |

### Ví dụ đồng bộ lịch sử offline

```http
POST /api/v1/me/history/sync
Content-Type: application/json
Authorization: Basic ...

{
  "events": [
    {
      "clientEventId": "5e9224fc-20f1-4c43-86df-56cf8dbf65bb",
      "artifactId": "30000000-0000-0000-0000-000000000001",
      "visitedAt": "2026-10-20T09:15:00Z",
      "source": "IBEACON",
      "beaconCode": "museum-beacon-01"
    }
  ]
}
```

`source` nhận một trong `IBEACON`, `MANUAL`, `MAP`. `clientEventId` phải được tạo trên thiết bị trước khi đưa sự kiện vào outbox và giữ nguyên khi retry.

## Quy tắc đồng bộ trên app

1. Khi ghi nhận lượt xem, app tạo một UUID `clientEventId`, lưu event vào local outbox ngay lập tức và tiếp tục hiển thị UI; không chờ mạng.
2. Khi có mạng, gửi batch `POST /api/v1/me/history/sync`. Chỉ xóa event khỏi outbox khi server báo nhận thành công. Nếu timeout, gửi lại đúng `clientEventId` cũ.
3. Favorite offline: cập nhật UI/local DB ngay, đồng thời xếp lệnh `ADD` hoặc `REMOVE` theo thứ tự phát sinh. Khi online, replay `PUT`/`DELETE` tuần tự; các endpoint này được thiết kế idempotent.
4. Cache nội dung: lấy manifest theo `siteId` và ngôn ngữ, so `contentHash`; tải những mục mới/đã thay đổi và lưu cùng `updatedAt`. Nếu mạng lỗi, dùng bản cache cũ đã tải.
5. Có chính sách giới hạn dung lượng (ví dụ theo số MB), dọn nội dung ít dùng trước nhưng giữ favorite nếu còn dung lượng. Giới hạn cụ thể cần thống nhất trong nhóm; không phải yêu cầu định lượng gốc trong đề tài.
6. Không cache JWT/password; tránh ghi thông tin nhạy cảm vào log; dữ liệu cá nhân trong cache phải có chính sách xóa khi logout.

## Kiểm thử đề xuất

- History: người dùng A không đọc được lịch sử người dùng B.
- Offline sync: cùng `clientEventId` retry 2 lần chỉ tạo một record.
- Favorites: PUT hai lần không tạo duplicate; DELETE lặp vẫn thành công.
- Cache: đúng `siteId`/language; hash thay đổi khiến app tải mới; mất mạng vẫn mở được nội dung đã lưu.
- Bảo mật: thiếu xác thực không được truy cập history/favorites; API không nhận `visitorId` từ client.
- Batch history là all-or-nothing trong starter này: nếu có artifact không tồn tại/chưa publish thì cả batch bị rollback. Nếu nhóm muốn xử lý từng event độc lập, cần đổi response/service thành partial success.

## Lưu ý tích hợp vào backend chính

Đây là module mẫu độc lập có `VisitorAccount` và `Artifact` tối giản để minh họa và chạy demo. Khi ghép vào backend chính, hãy thay bằng các entity User/Artifact thực tế để tránh tạo bảng/khái niệm trùng; giữ lại `VisitHistory`, `Favorite`, API/DTO và phần quy tắc đồng bộ sau khi chỉnh package/quan hệ.

## Phạm vi bàn giao và giới hạn

Xem [`docs/ASSIGNMENT_SUMMARY.md`](docs/ASSIGNMENT_SUMMARY.md) để đối chiếu từng yêu cầu US06/US07/US21/US22/US24 với mã nguồn và test. Lược đồ offline mobile đã tách local History khỏi event outbox và gắn dữ liệu cá nhân với `owner_user_id` cục bộ để tránh đồng bộ chéo tài khoản.

Phần backend là starter chạy demo độc lập với `VisitorAccount`/`Artifact` mẫu. Khi ghép vào hệ thống chính phải ánh xạ sang entity và principal JWT hiện tại. Mã lưu cache trên điện thoại phụ thuộc framework mobile của nhóm; gói này bàn giao schema và quy trình framework-agnostic, không giả định Flutter/React Native/Kotlin.
