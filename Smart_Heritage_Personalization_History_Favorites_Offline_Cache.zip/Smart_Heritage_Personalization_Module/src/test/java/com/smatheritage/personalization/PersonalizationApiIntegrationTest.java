package com.smatheritage.personalization;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smatheritage.personalization.config.DemoDataInitializer;
import com.smatheritage.personalization.domain.Artifact;
import com.smatheritage.personalization.domain.VisitHistory;
import com.smatheritage.personalization.domain.VisitSource;
import com.smatheritage.personalization.domain.VisitorAccount;
import com.smatheritage.personalization.repository.ArtifactRepository;
import com.smatheritage.personalization.repository.FavoriteRepository;
import com.smatheritage.personalization.repository.VisitHistoryRepository;
import com.smatheritage.personalization.repository.VisitorAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("demo")
class PersonalizationApiIntegrationTest {
    private static final String USERNAME = "visitor";
    private static final String PASSWORD = "demo123";
    private static final UUID ARTIFACT_ID = DemoDataInitializer.ARTIFACT_ID;
    private static final String BASE = "/api/v1";

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @Autowired private FavoriteRepository favoriteRepository;
    @Autowired private VisitHistoryRepository visitHistoryRepository;
    @Autowired private VisitorAccountRepository visitorAccountRepository;
    @Autowired private ArtifactRepository artifactRepository;

    @BeforeEach
    void cleanVisitorData() {
        favoriteRepository.deleteAllInBatch();
        visitHistoryRepository.deleteAllInBatch();
    }

    @Test
    void personalEndpointsRequireAuthentication() throws Exception {
        mockMvc.perform(get(BASE + "/me/history"))
            .andExpect(status().isUnauthorized());
        mockMvc.perform(get(BASE + "/me/favorites"))
            .andExpect(status().isUnauthorized());
    }

    @Test
    void favoriteOperationsAreIdempotent() throws Exception {
        mockMvc.perform(put(BASE + "/me/favorites/" + ARTIFACT_ID).with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isNoContent());
        mockMvc.perform(put(BASE + "/me/favorites/" + ARTIFACT_ID).with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isNoContent());

        mockMvc.perform(get(BASE + "/me/favorites?page=0&size=20").with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.content.length()").value(1))
            .andExpect(jsonPath("$.content[0].artifactId").value(ARTIFACT_ID.toString()));

        mockMvc.perform(delete(BASE + "/me/favorites/" + ARTIFACT_ID).with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isNoContent());
        mockMvc.perform(delete(BASE + "/me/favorites/" + ARTIFACT_ID).with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isNoContent());
    }

    @Test
    void historySyncIsIdempotentAcrossRetries() throws Exception {
        UUID eventId = UUID.randomUUID();
        Map<String, Object> event = Map.of(
            "clientEventId", eventId,
            "artifactId", ARTIFACT_ID,
            "visitedAt", Instant.parse("2026-10-20T09:15:00Z").toString(),
            "source", "IBEACON",
            "beaconCode", "demo-beacon-01"
        );
        String requestBody = objectMapper.writeValueAsString(Map.of("events", new Object[]{event}));

        mockMvc.perform(post(BASE + "/me/history/sync")
                .with(httpBasic(USERNAME, PASSWORD))
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.received").value(1))
            .andExpect(jsonPath("$.created").value(1))
            .andExpect(jsonPath("$.duplicates").value(0));

        mockMvc.perform(post(BASE + "/me/history/sync")
                .with(httpBasic(USERNAME, PASSWORD))
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.received").value(1))
            .andExpect(jsonPath("$.created").value(0))
            .andExpect(jsonPath("$.duplicates").value(1));

        mockMvc.perform(get(BASE + "/me/history?page=0&size=20").with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.totalElements").value(1));
    }


    @Test
    void historyIsScopedToAuthenticatedVisitor() throws Exception {
        UUID demoVisitorId = com.smatheritage.personalization.config.DemoSecurityConfig.DEMO_VISITOR_ID;
        VisitorAccount demoVisitor = visitorAccountRepository.findById(demoVisitorId).orElseThrow();
        UUID otherVisitorId = UUID.randomUUID();
        VisitorAccount otherVisitor = visitorAccountRepository.save(
            new VisitorAccount(otherVisitorId, "other-" + otherVisitorId + "@example.test", "Other Visitor"));
        Artifact artifact = artifactRepository.findByIdAndPublishedTrue(ARTIFACT_ID).orElseThrow();
        Instant when = Instant.parse("2026-10-19T08:00:00Z");
        visitHistoryRepository.save(new VisitHistory(UUID.randomUUID(), demoVisitor, artifact,
            UUID.randomUUID(), when, VisitSource.MANUAL, null));
        visitHistoryRepository.save(new VisitHistory(UUID.randomUUID(), otherVisitor, artifact,
            UUID.randomUUID(), when.plusSeconds(60), VisitSource.MANUAL, null));

        mockMvc.perform(get(BASE + "/me/history?page=0&size=20").with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.totalElements").value(1))
            .andExpect(jsonPath("$.content[0].artifactId").value(ARTIFACT_ID.toString()));
    }

    @Test
    void invalidArtifactMakesOfflineSyncBatchRollback() throws Exception {
        UUID event1 = UUID.randomUUID();
        UUID event2 = UUID.randomUUID();
        Map<String, Object> validEvent = Map.of(
            "clientEventId", event1,
            "artifactId", ARTIFACT_ID,
            "visitedAt", "2026-10-20T09:15:00Z",
            "source", "IBEACON"
        );
        Map<String, Object> missingArtifactEvent = Map.of(
            "clientEventId", event2,
            "artifactId", UUID.randomUUID(),
            "visitedAt", "2026-10-20T09:16:00Z",
            "source", "MANUAL"
        );
        String requestBody = objectMapper.writeValueAsString(Map.of("events", new Object[]{validEvent, missingArtifactEvent}));

        mockMvc.perform(post(BASE + "/me/history/sync")
                .with(httpBasic(USERNAME, PASSWORD))
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isNotFound());

        org.junit.jupiter.api.Assertions.assertEquals(0, visitHistoryRepository.count(),
            "The sync batch must roll back as one transaction when an artifact is not published or missing.");
    }

    @Test
    void offlineManifestReturnsRequestedLanguageAndContentHash() throws Exception {
        mockMvc.perform(get(BASE + "/offline-cache/manifest")
                .param("siteId", DemoDataInitializer.DEMO_SITE_ID.toString())
                .param("language", "VI")
                .with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.languageCode").value("vi"))
            .andExpect(jsonPath("$.itemCount").value(1))
            .andExpect(jsonPath("$.items[0].contentHash").value("demo-hash-v1"));
    }

    @Test
    void offlineManifestRejectsMalformedLanguageCode() throws Exception {
        mockMvc.perform(get(BASE + "/offline-cache/manifest")
                .param("siteId", DemoDataInitializer.DEMO_SITE_ID.toString())
                .param("language", "vietnamese")
                .with(httpBasic(USERNAME, PASSWORD)))
            .andExpect(status().isBadRequest());
    }
}
