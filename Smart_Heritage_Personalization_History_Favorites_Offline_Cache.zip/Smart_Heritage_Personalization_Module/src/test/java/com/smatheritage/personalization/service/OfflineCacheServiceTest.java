package com.smatheritage.personalization.service;

import com.smatheritage.personalization.domain.Artifact;
import com.smatheritage.personalization.domain.ArtifactContent;
import com.smatheritage.personalization.repository.ArtifactContentRepository;
import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class OfflineCacheServiceTest {
    @Test void manifestContainsHashAndLocalizedContentForClientValidation() {
        ArtifactContentRepository repository = mock(ArtifactContentRepository.class);
        UUID site = UUID.randomUUID();
        UUID artifactId = UUID.randomUUID();
        Instant now = Instant.now();
        Artifact artifact = new Artifact(artifactId, site, "Cổng di tích", "https://example.test/thumb.jpg", true, now);
        when(repository.findByArtifact_SiteIdAndLanguageCodeAndArtifact_PublishedTrueOrderByTitleAsc(site, "vi"))
            .thenReturn(List.of(new ArtifactContent(UUID.randomUUID(), artifact, "vi", "Cổng di tích",
                "Mô tả", "https://example.test/content.html", "sha256-v1", now)));
        var result = new OfflineCacheService(repository).getManifest(site, "VI");
        assertEquals(1, result.itemCount());
        assertEquals("vi", result.languageCode());
        assertEquals("sha256-v1", result.items().get(0).contentHash());
    }
}
