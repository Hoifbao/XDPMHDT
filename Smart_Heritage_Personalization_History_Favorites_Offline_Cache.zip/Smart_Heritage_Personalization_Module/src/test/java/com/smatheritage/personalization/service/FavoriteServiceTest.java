package com.smatheritage.personalization.service;

import com.smatheritage.personalization.domain.Artifact;
import com.smatheritage.personalization.domain.VisitorAccount;
import com.smatheritage.personalization.repository.ArtifactRepository;
import com.smatheritage.personalization.repository.FavoriteRepository;
import com.smatheritage.personalization.repository.VisitorAccountRepository;
import com.smatheritage.personalization.security.CurrentUserProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class FavoriteServiceTest {
    private FavoriteRepository favorites;
    private VisitorAccountRepository visitors;
    private ArtifactRepository artifacts;
    private CurrentUserProvider currentUser;
    private FavoriteService service;
    private final UUID visitorId = UUID.randomUUID();
    private final UUID artifactId = UUID.randomUUID();

    @BeforeEach void setUp() {
        favorites = mock(FavoriteRepository.class);
        visitors = mock(VisitorAccountRepository.class);
        artifacts = mock(ArtifactRepository.class);
        currentUser = () -> visitorId;
        service = new FavoriteService(favorites, visitors, artifacts, currentUser);
    }

    @Test void addingExistingFavoriteIsIdempotent() {
        when(favorites.existsByVisitor_IdAndArtifact_Id(visitorId, artifactId)).thenReturn(true);
        service.addFavorite(artifactId);
        verify(favorites, never()).save(any());
        verify(artifacts, never()).findByIdAndPublishedTrue(any());
    }

    @Test void newFavoriteIsStored() {
        when(favorites.existsByVisitor_IdAndArtifact_Id(visitorId, artifactId)).thenReturn(false);
        when(visitors.findById(visitorId)).thenReturn(Optional.of(new VisitorAccount(visitorId, "user@example.test", "Visitor")));
        when(artifacts.findByIdAndPublishedTrue(artifactId)).thenReturn(Optional.of(
            new Artifact(artifactId, UUID.randomUUID(), "Artifact", null, true, Instant.now())));
        service.addFavorite(artifactId);
        verify(favorites).save(any());
    }
}
