package com.smatheritage.personalization.service;

import com.smatheritage.personalization.domain.Artifact;
import com.smatheritage.personalization.domain.VisitHistory;
import com.smatheritage.personalization.domain.VisitSource;
import com.smatheritage.personalization.domain.VisitorAccount;
import com.smatheritage.personalization.dto.RecordVisitRequest;
import com.smatheritage.personalization.dto.SyncVisitsRequest;
import com.smatheritage.personalization.repository.ArtifactRepository;
import com.smatheritage.personalization.repository.VisitHistoryRepository;
import com.smatheritage.personalization.repository.VisitorAccountRepository;
import com.smatheritage.personalization.security.CurrentUserProvider;
import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class VisitHistoryServiceTest {
    @Test void duplicateClientEventIsNotInsertedTwiceDuringOfflineSync() {
        UUID visitorId = UUID.randomUUID();
        UUID artifactId = UUID.randomUUID();
        UUID clientEventId = UUID.randomUUID();
        Instant visitedAt = Instant.parse("2026-10-20T09:15:00Z");
        var histories = mock(VisitHistoryRepository.class);
        var visitors = mock(VisitorAccountRepository.class);
        var artifacts = mock(ArtifactRepository.class);
        CurrentUserProvider currentUser = () -> visitorId;
        var visitor = new VisitorAccount(visitorId, "v@example.test", "Visitor");
        var artifact = new Artifact(artifactId, UUID.randomUUID(), "Artifact", null, true, visitedAt);
        var existing = new VisitHistory(UUID.randomUUID(), visitor, artifact, clientEventId, visitedAt, VisitSource.IBEACON, "b-1");
        when(visitors.findById(visitorId)).thenReturn(Optional.of(visitor));
        when(histories.findByVisitor_IdAndClientEventId(visitorId, clientEventId))
            .thenReturn(Optional.empty(), Optional.of(existing));
        when(artifacts.findByIdAndPublishedTrue(artifactId)).thenReturn(Optional.of(artifact));
        var request = new SyncVisitsRequest(List.of(
            new RecordVisitRequest(clientEventId, artifactId, visitedAt, VisitSource.IBEACON, "b-1"),
            new RecordVisitRequest(clientEventId, artifactId, visitedAt, VisitSource.IBEACON, "b-1")
        ));

        var response = new VisitHistoryService(histories, visitors, artifacts, currentUser).syncOfflineVisits(request);
        assertEquals(2, response.received());
        assertEquals(1, response.created());
        assertEquals(1, response.duplicates());
        verify(histories, times(1)).save(any(VisitHistory.class));
    }
}
