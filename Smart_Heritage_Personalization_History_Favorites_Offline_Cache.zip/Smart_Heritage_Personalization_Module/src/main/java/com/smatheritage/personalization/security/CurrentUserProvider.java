package com.smatheritage.personalization.security;

import java.util.UUID;

public interface CurrentUserProvider {
    UUID requireCurrentUserId();
}
