package com.smatheritage.personalization.dto;

import com.smatheritage.personalization.domain.VisitSource;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.UUID;

public record RecordVisitRequest(
    @NotNull UUID clientEventId,
    @NotNull UUID artifactId,
    @NotNull Instant visitedAt,
    @NotNull VisitSource source,
    @Size(max = 120) String beaconCode
) { }
