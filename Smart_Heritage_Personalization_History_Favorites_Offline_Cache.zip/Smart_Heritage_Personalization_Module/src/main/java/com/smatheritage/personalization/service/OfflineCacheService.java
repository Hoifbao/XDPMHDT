package com.smatheritage.personalization.service;

import com.smatheritage.personalization.domain.ArtifactContent;
import com.smatheritage.personalization.dto.OfflineManifestItem;
import com.smatheritage.personalization.dto.OfflineManifestResponse;
import com.smatheritage.personalization.repository.ArtifactContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
public class OfflineCacheService {
    private final ArtifactContentRepository contentRepository;

    public OfflineCacheService(ArtifactContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    /** Returns metadata the mobile app uses to download/cache content locally; the server does not store the phone's cache. */
    @Transactional(readOnly = true)
    public OfflineManifestResponse getManifest(UUID siteId, String languageCode) {
        String normalizedLanguage = languageCode.trim().toLowerCase(Locale.ROOT);
        List<OfflineManifestItem> items = contentRepository
            .findByArtifact_SiteIdAndLanguageCodeAndArtifact_PublishedTrueOrderByTitleAsc(siteId, normalizedLanguage)
            .stream().map(this::toItem).toList();
        return new OfflineManifestResponse(siteId, normalizedLanguage, Instant.now(), items.size(), items);
    }

    private OfflineManifestItem toItem(ArtifactContent content) {
        var artifact = content.getArtifact();
        return new OfflineManifestItem(artifact.getId(), content.getLanguageCode(), content.getTitle(),
            content.getDescription(), artifact.getThumbnailUrl(), content.getContentUrl(),
            content.getContentHash(), content.getUpdatedAt());
    }
}
