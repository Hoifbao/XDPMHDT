package com.smatheritage.personalization.service;

import com.smatheritage.personalization.domain.Artifact;
import com.smatheritage.personalization.domain.Favorite;
import com.smatheritage.personalization.domain.VisitorAccount;
import com.smatheritage.personalization.dto.FavoriteResponse;
import com.smatheritage.personalization.dto.PageResponse;
import com.smatheritage.personalization.exception.ResourceNotFoundException;
import com.smatheritage.personalization.repository.ArtifactRepository;
import com.smatheritage.personalization.repository.FavoriteRepository;
import com.smatheritage.personalization.repository.VisitorAccountRepository;
import com.smatheritage.personalization.security.CurrentUserProvider;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;
import java.util.UUID;

@Service
public class FavoriteService {
    private final FavoriteRepository favoriteRepository;
    private final VisitorAccountRepository visitorRepository;
    private final ArtifactRepository artifactRepository;
    private final CurrentUserProvider currentUserProvider;

    public FavoriteService(FavoriteRepository favoriteRepository, VisitorAccountRepository visitorRepository,
                          ArtifactRepository artifactRepository, CurrentUserProvider currentUserProvider) {
        this.favoriteRepository = favoriteRepository;
        this.visitorRepository = visitorRepository;
        this.artifactRepository = artifactRepository;
        this.currentUserProvider = currentUserProvider;
    }

    @Transactional(readOnly = true)
    public PageResponse<FavoriteResponse> getMyFavorites(int page, int size) {
        UUID visitorId = currentUserProvider.requireCurrentUserId();
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Favorite> result = favoriteRepository.findByVisitor_IdOrderByCreatedAtDesc(visitorId, pageable);
        return PageResponse.from(result.map(this::toResponse));
    }

    /** Idempotent PUT semantics: adding an existing favorite does not create a duplicate row. */
    @Transactional
    public void addFavorite(UUID artifactId) {
        UUID visitorId = currentUserProvider.requireCurrentUserId();
        if (favoriteRepository.existsByVisitor_IdAndArtifact_Id(visitorId, artifactId)) return;
        VisitorAccount visitor = visitorRepository.findById(visitorId)
            .orElseThrow(() -> new ResourceNotFoundException("Visitor account was not found."));
        Artifact artifact = artifactRepository.findByIdAndPublishedTrue(artifactId)
            .orElseThrow(() -> new ResourceNotFoundException("Published artifact was not found: " + artifactId));
        // A database unique constraint on (visitor_id, artifact_id) is the final duplicate guard.
        favoriteRepository.save(new Favorite(UUID.randomUUID(), visitor, artifact, Instant.now()));
    }

    @Transactional
    public void removeFavorite(UUID artifactId) {
        UUID visitorId = currentUserProvider.requireCurrentUserId();
        favoriteRepository.deleteByVisitor_IdAndArtifact_Id(visitorId, artifactId);
    }

    @Transactional(readOnly = true)
    public boolean isFavorite(UUID artifactId) {
        return favoriteRepository.existsByVisitor_IdAndArtifact_Id(currentUserProvider.requireCurrentUserId(), artifactId);
    }

    private FavoriteResponse toResponse(Favorite favorite) {
        Artifact artifact = favorite.getArtifact();
        return new FavoriteResponse(artifact.getId(), artifact.getDefaultTitle(),
            artifact.getThumbnailUrl(), favorite.getCreatedAt());
    }
}
