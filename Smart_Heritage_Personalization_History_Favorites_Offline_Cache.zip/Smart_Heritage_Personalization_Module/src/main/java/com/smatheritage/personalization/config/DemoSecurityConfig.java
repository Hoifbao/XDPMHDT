package com.smatheritage.personalization.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import java.util.UUID;

@Configuration
@Profile("demo")
public class DemoSecurityConfig {
    public static final UUID DEMO_VISITOR_ID = UUID.fromString("10000000-0000-0000-0000-000000000001");
    @Bean
    UserDetailsService demoUsers() {
        // Demo credentials are only for local testing. Use the project's real JWT security in integration.
        return new InMemoryUserDetailsManager(new DemoVisitorPrincipal(DEMO_VISITOR_ID, "visitor", "{noop}demo123"));
    }
    @Bean
    SecurityFilterChain demoFilterChain(HttpSecurity http) throws Exception {
        return http.csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth.anyRequest().authenticated())
            .httpBasic(Customizer.withDefaults())
            .build();
    }
}
