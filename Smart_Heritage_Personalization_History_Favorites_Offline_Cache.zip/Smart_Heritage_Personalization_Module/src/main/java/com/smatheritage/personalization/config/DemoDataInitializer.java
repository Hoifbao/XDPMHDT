package com.smatheritage.personalization.config;

import com.smatheritage.personalization.domain.Artifact;
import com.smatheritage.personalization.domain.ArtifactContent;
import com.smatheritage.personalization.domain.VisitorAccount;
import com.smatheritage.personalization.repository.ArtifactContentRepository;
import com.smatheritage.personalization.repository.ArtifactRepository;
import com.smatheritage.personalization.repository.VisitorAccountRepository;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import java.time.Instant;
import java.util.UUID;

@Configuration
@Profile("demo")
public class DemoDataInitializer {
    public static final UUID DEMO_SITE_ID = UUID.fromString("20000000-0000-0000-0000-000000000001");
    public static final UUID ARTIFACT_ID = UUID.fromString("30000000-0000-0000-0000-000000000001");

    @Bean
    ApplicationRunner seedDemoData(VisitorAccountRepository visitors, ArtifactRepository artifacts,
                                   ArtifactContentRepository contents) {
        return args -> {
            Instant now = Instant.now();
            if (!visitors.existsById(DemoSecurityConfig.DEMO_VISITOR_ID)) {
                visitors.save(new VisitorAccount(DemoSecurityConfig.DEMO_VISITOR_ID, "visitor@example.test", "Demo Visitor"));
            }
            Artifact artifact = artifacts.findById(ARTIFACT_ID).orElseGet(() -> artifacts.save(
                new Artifact(ARTIFACT_ID, DEMO_SITE_ID, "Mẫu hiện vật Smart Heritage",
                    "https://example.test/images/artifact.jpg", true, now)));
            if (contents.count() == 0) {
                contents.save(new ArtifactContent(UUID.randomUUID(), artifact, "vi", "Mẫu hiện vật Smart Heritage",
                    "Nội dung minh họa cho chức năng cache ngoại tuyến.",
                    "https://example.test/content/artifact.html", "demo-hash-v1", now));
                contents.save(new ArtifactContent(UUID.randomUUID(), artifact, "en", "Smart Heritage sample artifact",
                    "Demonstration content for offline cache.",
                    "https://example.test/content/artifact-en.html", "demo-hash-en-v1", now));
            }
        };
    }
}
