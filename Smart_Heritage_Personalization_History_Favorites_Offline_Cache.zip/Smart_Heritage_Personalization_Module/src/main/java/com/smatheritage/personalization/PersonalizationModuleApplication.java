package com.smatheritage.personalization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalizationModuleApplication {
    public static void main(String[] args) {
        SpringApplication.run(PersonalizationModuleApplication.class, args);
    }
}
