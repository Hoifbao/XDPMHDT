package com.smatheritage.personalization.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "favorites", uniqueConstraints = {
    @UniqueConstraint(name = "uk_favorite_visitor_artifact", columnNames = {"visitor_id", "artifact_id"})
})
public class Favorite {
    @Id
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "visitor_id", nullable = false)
    private VisitorAccount visitor;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "artifact_id", nullable = false)
    private Artifact artifact;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    protected Favorite() { }

    public Favorite(UUID id, VisitorAccount visitor, Artifact artifact, Instant createdAt) {
        this.id = id;
        this.visitor = visitor;
        this.artifact = artifact;
        this.createdAt = createdAt;
    }

    public UUID getId() { return id; }
    public VisitorAccount getVisitor() { return visitor; }
    public Artifact getArtifact() { return artifact; }
    public Instant getCreatedAt() { return createdAt; }
}
