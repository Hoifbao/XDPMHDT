package com.smatheritage.personalization.repository;

import com.smatheritage.personalization.domain.VisitorAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface VisitorAccountRepository extends JpaRepository<VisitorAccount, UUID> { }
