package com.smatheritage.personalization.repository;

import com.smatheritage.personalization.domain.ArtifactContent;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface ArtifactContentRepository extends JpaRepository<ArtifactContent, UUID> {
    @EntityGraph(attributePaths = "artifact")
    List<ArtifactContent> findByArtifact_SiteIdAndLanguageCodeAndArtifact_PublishedTrueOrderByTitleAsc(
        UUID siteId, String languageCode);
}
