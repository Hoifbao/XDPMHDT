package com.smatheritage.personalization.dto;

import java.time.Instant;
import java.util.UUID;

public record OfflineManifestItem(UUID artifactId, String languageCode, String title,
                                  String description, String thumbnailUrl, String contentUrl,
                                  String contentHash, Instant updatedAt) { }
