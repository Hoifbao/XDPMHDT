package com.smatheritage.personalization.service;

import com.smatheritage.personalization.domain.Artifact;
import com.smatheritage.personalization.domain.VisitHistory;
import com.smatheritage.personalization.domain.VisitorAccount;
import com.smatheritage.personalization.dto.PageResponse;
import com.smatheritage.personalization.dto.RecordVisitRequest;
import com.smatheritage.personalization.dto.SyncVisitsRequest;
import com.smatheritage.personalization.dto.SyncVisitsResponse;
import com.smatheritage.personalization.dto.VisitHistoryResponse;
import com.smatheritage.personalization.exception.ResourceNotFoundException;
import com.smatheritage.personalization.repository.ArtifactRepository;
import com.smatheritage.personalization.repository.VisitHistoryRepository;
import com.smatheritage.personalization.repository.VisitorAccountRepository;
import com.smatheritage.personalization.security.CurrentUserProvider;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.UUID;

@Service
public class VisitHistoryService {
    private final VisitHistoryRepository historyRepository;
    private final VisitorAccountRepository visitorRepository;
    private final ArtifactRepository artifactRepository;
    private final CurrentUserProvider currentUserProvider;

    public VisitHistoryService(VisitHistoryRepository historyRepository,
                               VisitorAccountRepository visitorRepository,
                               ArtifactRepository artifactRepository,
                               CurrentUserProvider currentUserProvider) {
        this.historyRepository = historyRepository;
        this.visitorRepository = visitorRepository;
        this.artifactRepository = artifactRepository;
        this.currentUserProvider = currentUserProvider;
    }

    @Transactional(readOnly = true)
    public PageResponse<VisitHistoryResponse> getMyHistory(int page, int size) {
        UUID visitorId = currentUserProvider.requireCurrentUserId();
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "visitedAt"));
        Page<VisitHistory> result = historyRepository.findByVisitor_IdOrderByVisitedAtDesc(visitorId, pageable);
        return PageResponse.from(result.map(this::toResponse));
    }

    /** Whole batch is transactional: if a non-existent/unpublished artifact is supplied, no events in the batch are committed. */
    @Transactional
    public SyncVisitsResponse syncOfflineVisits(SyncVisitsRequest request) {
        UUID visitorId = currentUserProvider.requireCurrentUserId();
        VisitorAccount visitor = visitorRepository.findById(visitorId)
            .orElseThrow(() -> new ResourceNotFoundException("Visitor account was not found."));
        int created = 0;
        int duplicates = 0;
        for (RecordVisitRequest event : request.events()) {
            if (historyRepository.findByVisitor_IdAndClientEventId(visitorId, event.clientEventId()).isPresent()) {
                duplicates++;
                continue;
            }
            Artifact artifact = artifactRepository.findByIdAndPublishedTrue(event.artifactId())
                .orElseThrow(() -> new ResourceNotFoundException("Published artifact was not found: " + event.artifactId()));
            VisitHistory history = new VisitHistory(UUID.randomUUID(), visitor, artifact,
                event.clientEventId(), event.visitedAt(), event.source(), event.beaconCode());
            historyRepository.save(history);
            created++;
        }
        return new SyncVisitsResponse(request.events().size(), created, duplicates);
    }

    private VisitHistoryResponse toResponse(VisitHistory history) {
        Artifact artifact = history.getArtifact();
        return new VisitHistoryResponse(history.getId(), artifact.getId(), artifact.getDefaultTitle(),
            artifact.getThumbnailUrl(), history.getVisitedAt(), history.getSource(), history.getBeaconCode());
    }
}
