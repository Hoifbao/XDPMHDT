package com.smatheritage.personalization.dto;

public record SyncVisitsResponse(int received, int created, int duplicates) { }
