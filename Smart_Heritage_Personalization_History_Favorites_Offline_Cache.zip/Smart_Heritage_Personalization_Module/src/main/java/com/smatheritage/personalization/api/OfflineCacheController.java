package com.smatheritage.personalization.api;

import com.smatheritage.personalization.dto.OfflineManifestResponse;
import com.smatheritage.personalization.service.OfflineCacheService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/offline-cache")
public class OfflineCacheController {
    private final OfflineCacheService service;
    public OfflineCacheController(OfflineCacheService service) { this.service = service; }

    @GetMapping("/manifest")
    public OfflineManifestResponse getManifest(
        @RequestParam UUID siteId,
        @RequestParam @NotBlank @Pattern(regexp = "^[a-z]{2}(-[A-Za-z]{2})?$", message = "language must look like vi or en-us") String language) {
        return service.getManifest(siteId, language);
    }
}
