package com.smatheritage.personalization.repository;

import com.smatheritage.personalization.domain.Artifact;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ArtifactRepository extends JpaRepository<Artifact, UUID> {
    Optional<Artifact> findByIdAndPublishedTrue(UUID id);
    List<Artifact> findBySiteIdAndPublishedTrueOrderByDefaultTitleAsc(UUID siteId);
}
