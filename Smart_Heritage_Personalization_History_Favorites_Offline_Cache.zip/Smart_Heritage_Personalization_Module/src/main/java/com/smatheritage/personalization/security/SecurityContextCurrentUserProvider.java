package com.smatheritage.personalization.security;

import com.smatheritage.personalization.exception.UnauthenticatedUserException;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import java.util.UUID;

@Component
public class SecurityContextCurrentUserProvider implements CurrentUserProvider {
    @Override
    public UUID requireCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || authentication instanceof AnonymousAuthenticationToken) {
            throw new UnauthenticatedUserException("Authentication is required.");
        }
        Object principal = authentication.getPrincipal();
        if (principal instanceof CurrentUserPrincipal currentUserPrincipal) {
            return currentUserPrincipal.getUserId();
        }
        throw new IllegalStateException("Authenticated principal must implement CurrentUserPrincipal and expose its UUID userId.");
    }
}
