package com.smatheritage.personalization.dto;

import java.time.Instant;
import java.util.UUID;

public record FavoriteResponse(UUID artifactId, String artifactTitle, String thumbnailUrl,
                               Instant favoritedAt) { }
