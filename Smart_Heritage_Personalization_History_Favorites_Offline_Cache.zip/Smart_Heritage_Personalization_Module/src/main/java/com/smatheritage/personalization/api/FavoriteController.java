package com.smatheritage.personalization.api;

import com.smatheritage.personalization.dto.FavoriteResponse;
import com.smatheritage.personalization.dto.PageResponse;
import com.smatheritage.personalization.service.FavoriteService;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/me/favorites")
public class FavoriteController {
    private final FavoriteService service;

    public FavoriteController(FavoriteService service) { this.service = service; }

    @GetMapping
    public PageResponse<FavoriteResponse> getFavorites(
        @RequestParam(defaultValue = "0") @Min(0) int page,
        @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size) {
        return service.getMyFavorites(page, size);
    }

    @PutMapping("/{artifactId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void addFavorite(@PathVariable UUID artifactId) { service.addFavorite(artifactId); }

    @DeleteMapping("/{artifactId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removeFavorite(@PathVariable UUID artifactId) { service.removeFavorite(artifactId); }

    @GetMapping("/{artifactId}/exists")
    public boolean isFavorite(@PathVariable UUID artifactId) { return service.isFavorite(artifactId); }
}
