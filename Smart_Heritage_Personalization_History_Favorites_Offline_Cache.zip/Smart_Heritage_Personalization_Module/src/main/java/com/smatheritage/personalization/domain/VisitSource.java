package com.smatheritage.personalization.domain;

public enum VisitSource {
    IBEACON,
    MANUAL,
    MAP
}
