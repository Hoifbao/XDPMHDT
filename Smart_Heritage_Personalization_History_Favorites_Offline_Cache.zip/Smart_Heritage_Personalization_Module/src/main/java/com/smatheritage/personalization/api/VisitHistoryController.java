package com.smatheritage.personalization.api;

import com.smatheritage.personalization.dto.PageResponse;
import com.smatheritage.personalization.dto.SyncVisitsRequest;
import com.smatheritage.personalization.dto.SyncVisitsResponse;
import com.smatheritage.personalization.dto.VisitHistoryResponse;
import com.smatheritage.personalization.service.VisitHistoryService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/me/history")
public class VisitHistoryController {
    private final VisitHistoryService service;

    public VisitHistoryController(VisitHistoryService service) { this.service = service; }

    @GetMapping
    public PageResponse<VisitHistoryResponse> getHistory(
        @RequestParam(defaultValue = "0") @Min(0) int page,
        @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size) {
        return service.getMyHistory(page, size);
    }

    @PostMapping("/sync")
    public SyncVisitsResponse syncOfflineHistory(@Valid @RequestBody SyncVisitsRequest request) {
        return service.syncOfflineVisits(request);
    }
}
