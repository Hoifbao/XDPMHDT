package com.smatheritage.personalization.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "artifact_contents", uniqueConstraints = {
    @UniqueConstraint(name = "uk_artifact_language", columnNames = {"artifact_id", "language_code"})
})
public class ArtifactContent {
    @Id
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "artifact_id", nullable = false)
    private Artifact artifact;

    @Column(name = "language_code", nullable = false, length = 12)
    private String languageCode;

    @Column(nullable = false, length = 180)
    private String title;

    @Column(length = 8000)
    private String description;

    @Column(length = 2000)
    private String contentUrl;

    @Column(length = 128)
    private String contentHash;

    @Column(nullable = false)
    private Instant updatedAt;

    protected ArtifactContent() { }

    public ArtifactContent(UUID id, Artifact artifact, String languageCode, String title,
                           String description, String contentUrl, String contentHash, Instant updatedAt) {
        this.id = id;
        this.artifact = artifact;
        this.languageCode = languageCode;
        this.title = title;
        this.description = description;
        this.contentUrl = contentUrl;
        this.contentHash = contentHash;
        this.updatedAt = updatedAt;
    }

    public UUID getId() { return id; }
    public Artifact getArtifact() { return artifact; }
    public String getLanguageCode() { return languageCode; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getContentUrl() { return contentUrl; }
    public String getContentHash() { return contentHash; }
    public Instant getUpdatedAt() { return updatedAt; }
}
