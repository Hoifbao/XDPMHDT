package com.smatheritage.personalization.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "heritage_artifacts")
public class Artifact {
    @Id
    private UUID id;

    @Column(nullable = false)
    private UUID siteId;

    @Column(nullable = false, length = 180)
    private String defaultTitle;

    @Column(length = 1000)
    private String thumbnailUrl;

    @Column(nullable = false)
    private boolean published;

    @Column(nullable = false)
    private Instant updatedAt;

    protected Artifact() { }

    public Artifact(UUID id, UUID siteId, String defaultTitle, String thumbnailUrl, boolean published, Instant updatedAt) {
        this.id = id;
        this.siteId = siteId;
        this.defaultTitle = defaultTitle;
        this.thumbnailUrl = thumbnailUrl;
        this.published = published;
        this.updatedAt = updatedAt;
    }

    public UUID getId() { return id; }
    public UUID getSiteId() { return siteId; }
    public String getDefaultTitle() { return defaultTitle; }
    public String getThumbnailUrl() { return thumbnailUrl; }
    public boolean isPublished() { return published; }
    public Instant getUpdatedAt() { return updatedAt; }
}
