package com.smatheritage.personalization.security;

import java.util.UUID;

/** Implement this interface on the principal returned by the project's JWT/UserDetails service. */
public interface CurrentUserPrincipal {
    UUID getUserId();
}
