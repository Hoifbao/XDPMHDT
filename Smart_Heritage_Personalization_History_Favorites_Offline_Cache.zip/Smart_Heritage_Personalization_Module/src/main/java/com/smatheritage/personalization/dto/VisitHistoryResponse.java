package com.smatheritage.personalization.dto;

import com.smatheritage.personalization.domain.VisitSource;
import java.time.Instant;
import java.util.UUID;

public record VisitHistoryResponse(UUID id, UUID artifactId, String artifactTitle,
                                   String thumbnailUrl, Instant visitedAt,
                                   VisitSource source, String beaconCode) { }
