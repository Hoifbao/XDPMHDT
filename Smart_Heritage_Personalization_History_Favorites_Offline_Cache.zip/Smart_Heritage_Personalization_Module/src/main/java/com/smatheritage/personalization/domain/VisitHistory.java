package com.smatheritage.personalization.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "visit_history", uniqueConstraints = {
    @UniqueConstraint(name = "uk_visit_user_client_event", columnNames = {"visitor_id", "client_event_id"})
})
public class VisitHistory {
    @Id
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "visitor_id", nullable = false)
    private VisitorAccount visitor;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "artifact_id", nullable = false)
    private Artifact artifact;

    @Column(name = "client_event_id", nullable = false)
    private UUID clientEventId;

    @Column(name = "visited_at", nullable = false)
    private Instant visitedAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 24)
    private VisitSource source;

    @Column(length = 120)
    private String beaconCode;

    protected VisitHistory() { }

    public VisitHistory(UUID id, VisitorAccount visitor, Artifact artifact, UUID clientEventId,
                        Instant visitedAt, VisitSource source, String beaconCode) {
        this.id = id;
        this.visitor = visitor;
        this.artifact = artifact;
        this.clientEventId = clientEventId;
        this.visitedAt = visitedAt;
        this.source = source;
        this.beaconCode = beaconCode;
    }

    public UUID getId() { return id; }
    public VisitorAccount getVisitor() { return visitor; }
    public Artifact getArtifact() { return artifact; }
    public UUID getClientEventId() { return clientEventId; }
    public Instant getVisitedAt() { return visitedAt; }
    public VisitSource getSource() { return source; }
    public String getBeaconCode() { return beaconCode; }
}
