package com.smatheritage.personalization.config;

import com.smatheritage.personalization.security.CurrentUserPrincipal;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/** Local-only principal used by the demo profile. Do not use this identity in production. */
public class DemoVisitorPrincipal implements UserDetails, CurrentUserPrincipal {
    private final UUID userId;
    private final String username;
    private final String password;

    public DemoVisitorPrincipal(UUID userId, String username, String password) {
        this.userId = userId; this.username = username; this.password = password;
    }
    @Override public UUID getUserId() { return userId; }
    @Override public Collection<? extends GrantedAuthority> getAuthorities() { return List.of(new SimpleGrantedAuthority("ROLE_VISITOR")); }
    @Override public String getPassword() { return password; }
    @Override public String getUsername() { return username; }
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return true; }
}
