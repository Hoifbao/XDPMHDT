package com.smatheritage.personalization.repository;

import com.smatheritage.personalization.domain.VisitHistory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface VisitHistoryRepository extends JpaRepository<VisitHistory, UUID> {
    @EntityGraph(attributePaths = "artifact")
    Page<VisitHistory> findByVisitor_IdOrderByVisitedAtDesc(UUID visitorId, Pageable pageable);
    Optional<VisitHistory> findByVisitor_IdAndClientEventId(UUID visitorId, UUID clientEventId);
}
