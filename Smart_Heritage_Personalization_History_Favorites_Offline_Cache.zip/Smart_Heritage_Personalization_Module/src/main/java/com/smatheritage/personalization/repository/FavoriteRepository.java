package com.smatheritage.personalization.repository;

import com.smatheritage.personalization.domain.Favorite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface FavoriteRepository extends JpaRepository<Favorite, UUID> {
    @EntityGraph(attributePaths = "artifact")
    Page<Favorite> findByVisitor_IdOrderByCreatedAtDesc(UUID visitorId, Pageable pageable);
    Optional<Favorite> findByVisitor_IdAndArtifact_Id(UUID visitorId, UUID artifactId);
    boolean existsByVisitor_IdAndArtifact_Id(UUID visitorId, UUID artifactId);
    void deleteByVisitor_IdAndArtifact_Id(UUID visitorId, UUID artifactId);
}
