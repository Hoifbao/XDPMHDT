package com.smatheritage.personalization.dto;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public record OfflineManifestResponse(UUID siteId, String languageCode, Instant generatedAt,
                                     int itemCount, List<OfflineManifestItem> items) { }
